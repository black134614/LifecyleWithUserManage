import { combineReducers } from 'redux';
import QuanLyNguoiDungReducer from '../Reducers/QuanLyNguoiDungReducer'

export const rootReducer = combineReducers({
    QuanLyNguoiDungReducer
})