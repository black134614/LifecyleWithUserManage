export const add_user = 'add_user';
export const check_userRegister = 'check_userRegister';
export const delete_user = 'delete_user';
export const update_user = 'update_user';
export const edit_user = 'edit_user';