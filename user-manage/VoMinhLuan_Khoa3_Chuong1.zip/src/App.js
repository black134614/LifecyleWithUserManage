import './App.css';
import BaiTapQuanLyNguoiDung from './Components/BaiTapQuanLyNguoiDung';

function App() {
  return (
    <div className="App">
      <BaiTapQuanLyNguoiDung/>
    </div>
  );
}

export default App;
